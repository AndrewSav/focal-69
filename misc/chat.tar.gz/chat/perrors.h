case 1:
   fprintf ( stderr, "Missing '-', '(', NUM, VAR, FNAME, " );
   break;
case 2:
   fprintf ( stderr, "Missing EOS, '+', '-', " );
   break;
case 3:
   fprintf ( stderr, "Missing '*', '/', " );
   break;
case 4:
   fprintf ( stderr, "Missing '(', NUM, VAR, FNAME, " );
   break;
case 5:
   fprintf ( stderr, "Missing '^', " );
   break;
case 6:
   fprintf ( stderr, "Missing " );
   break;
case 7:
   fprintf ( stderr, "Missing '-', '(', NUM, VAR, FNAME, " );
   break;
case 8:
   fprintf ( stderr, "Missing " );
   break;
case 9:
   fprintf ( stderr, "Missing " );
   break;
case 10:
   fprintf ( stderr, "Missing " );
   break;
case 11:
   fprintf ( stderr, "Missing '(', " );
   break;
case 12:
   fprintf ( stderr, "Missing " );
   break;
case 13:
   fprintf ( stderr, "Missing '(', " );
   break;
case 14:
   fprintf ( stderr, "Missing " );
   break;
case 15:
   fprintf ( stderr, "Missing '(', NUM, VAR, FNAME, " );
   break;
case 16:
   fprintf ( stderr, "Missing '(', NUM, VAR, FNAME, " );
   break;
case 17:
   fprintf ( stderr, "Missing '(', NUM, VAR, FNAME, " );
   break;
case 18:
   fprintf ( stderr, "Missing '(', NUM, VAR, FNAME, " );
   break;
case 19:
   fprintf ( stderr, "Missing '*', '/', " );
   break;
case 20:
   fprintf ( stderr, "Missing '(', NUM, VAR, FNAME, " );
   break;
case 21:
   fprintf ( stderr, "Missing ')', '+', '-', " );
   break;
case 22:
   fprintf ( stderr, "Missing '-', '(', NUM, VAR, FNAME, " );
   break;
case 23:
   fprintf ( stderr, "Missing '-', '(', NUM, VAR, FNAME, " );
   break;
case 24:
   fprintf ( stderr, "Missing '*', '/', " );
   break;
case 25:
   fprintf ( stderr, "Missing '*', '/', " );
   break;
case 26:
   fprintf ( stderr, "Missing '^', " );
   break;
case 27:
   fprintf ( stderr, "Missing '^', " );
   break;
case 28:
   fprintf ( stderr, "Missing " );
   break;
case 29:
   fprintf ( stderr, "Missing " );
   break;
case 30:
   fprintf ( stderr, "Missing ')', '+', '-', " );
   break;
case 31:
   fprintf ( stderr, "Missing ')', '+', '-', " );
   break;
case 32:
   fprintf ( stderr, "Missing " );
   break;
case 33:
   fprintf ( stderr, "Missing " );
   break;
