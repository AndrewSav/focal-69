/*****************************************************************
* Parser tables, Generated at Wed Nov 11 11:31:09 1998
*****************************************************************/
/*
** Parser action macros
*/
#define SHIFT(co,ar)  (ar<<8|co)
#define REDUCE(co)    (co<<8|0xFF)
#define ERROR         -1
#define GOTO(c,n)     (n<<8|(c&255))

/*
** Parser token type equates
*/
#define EOS     3
#define NUM     14
#define FNAME   16

/*
** SLR(1) parser action tables
*/
static short int P1[] = {
       SHIFT('-',4),
       SHIFT('(',7),
       SHIFT(NUM,8),
       SHIFT(FNAME,10),
       ERROR
};
static short int P2[] = {
       SHIFT(EOS,11),
       SHIFT('+',13),
       SHIFT('-',12),
       ERROR
};
static short int P3[] = {
       SHIFT('*',14),
       SHIFT('/',15),
       REDUCE(2)
};
static short int P4[] = {
       SHIFT('(',7),
       SHIFT(NUM,8),
       SHIFT(FNAME,10),
       ERROR
};
static short int P5[] = {
       SHIFT('^',17),
       REDUCE(6)
};
static short int P6[] = {
       REDUCE(9)
};
static short int P7[] = {
       SHIFT('-',4),
       SHIFT('(',7),
       SHIFT(NUM,8),
       SHIFT(FNAME,10),
       ERROR
};
static short int P8[] = {
       REDUCE(12)
};
static short int P9[] = {
       REDUCE(13)
};
static short int P10[] = {
       SHIFT('(',19),
       ERROR
};
static short int P11[] = {
       REDUCE(1)
};
static short int P12[] = {
       SHIFT('(',7),
       SHIFT(NUM,8),
       SHIFT(FNAME,10),
       ERROR
};
static short int P13[] = {
       SHIFT('(',7),
       SHIFT(NUM,8),
       SHIFT(FNAME,10),
       ERROR
};
static short int P14[] = {
       SHIFT('(',7),
       SHIFT(NUM,8),
       SHIFT(FNAME,10),
       ERROR
};
static short int P15[] = {
       SHIFT('(',7),
       SHIFT(NUM,8),
       SHIFT(FNAME,10),
       ERROR
};
static short int P16[] = {
       SHIFT('*',14),
       SHIFT('/',15),
       REDUCE(3)
};
static short int P17[] = {
       SHIFT('(',7),
       SHIFT(NUM,8),
       SHIFT(FNAME,10),
       ERROR
};
static short int P18[] = {
       SHIFT(')',25),
       SHIFT('+',13),
       SHIFT('-',12),
       ERROR
};
static short int P19[] = {
       SHIFT('-',4),
       SHIFT('(',7),
       SHIFT(NUM,8),
       SHIFT(FNAME,10),
       ERROR
};
static short int P20[] = {
       SHIFT('*',14),
       SHIFT('/',15),
       REDUCE(5)
};
static short int P21[] = {
       SHIFT('*',14),
       SHIFT('/',15),
       REDUCE(4)
};
static short int P22[] = {
       SHIFT('^',17),
       REDUCE(7)
};
static short int P23[] = {
       SHIFT('^',17),
       REDUCE(8)
};
static short int P24[] = {
       REDUCE(10)
};
static short int P25[] = {
       REDUCE(11)
};
static short int P26[] = {
       SHIFT(')',27),
       SHIFT('+',13),
       SHIFT('-',12),
       ERROR
};
static short int P27[] = {
       REDUCE(14)
};

static short int const *parsetable[] = {
       P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, 
       P12, P13, P14, P15, P16, P17, P18, P19, P20, P21, 
       P22, P23, P24, P25, P26, P27
};

/*
** SLR(1) parser goto tables
*/
static short int GOAL[] = {
       GOTO(-1,0)
};
static short int EXPR[] = {
       GOTO(1,2),
       GOTO(7,18),
       GOTO(-1,26)
};
static short int TERM[] = {
       GOTO(4,16),
       GOTO(12,20),
       GOTO(13,21),
       GOTO(-1,3)
};
static short int FACT[] = {
       GOTO(14,22),
       GOTO(15,23),
       GOTO(-1,5)
};
static short int PRIM[] = {
       GOTO(17,24),
       GOTO(-1,6)
};
static short int FUNC[] = {
       GOTO(-1,9)
};

static struct {
   short int *go;
   int  handle;
} const gototable[] = {
   /* G1 */ GOAL,2,
   /* G2 */ EXPR,1,
   /* G3 */ EXPR,2,
   /* G4 */ EXPR,3,
   /* G5 */ EXPR,3,
   /* G6 */ TERM,1,
   /* G7 */ TERM,3,
   /* G8 */ TERM,3,
   /* G9 */ FACT,1,
   /* G10 */ FACT,3,
   /* G11 */ PRIM,3,
   /* G12 */ PRIM,1,
   /* G13 */ PRIM,1,
   /* G14 */ FUNC,4
};
